#import <voxy:lod/pos_util.glsl>
#import <voxy:lod/lighting.glsl>
//Common utility functions for decoding and operating on quads

vec3 swizzelDataAxis(uint axis, vec3 data) {
    return mix(mix(data.zxy,data.xzy,bvec3(axis==0)),data,bvec3(axis==1));
}

vec4 getFaceSize(uint faceData) {
    float EPSILON = 0.00005f;

    vec4 faceOffsetsSizes = extractFaceSizes(faceData);

    //Expand the quads by a very small amount (because of the subtraction after this also becomes an implicit add)
    faceOffsetsSizes.xz -= vec2(EPSILON);

    //Make the end relative to the start
    faceOffsetsSizes.yw -= faceOffsetsSizes.xz;

    return faceOffsetsSizes;
}


vec2 taaOffset = vec2(0);//TODO: compute this

struct QuadData {
    uvec4 attributeData;

    float lodScale;
    uint axis;
    //Used for computing the 4 corners of the quad
    vec3 basePoint;
    vec2 quadSizeAddin;
    vec2 uvCorner;
};

uint makeQuadFlags(uint faceData, uint modelId, ivec2 quadSize, const in BlockModel model, uint face) {
    //bit: 0-use cuttout, 1-dont use mipmaps, 2|3-tint state, 4|6-face, 8|11-width, 12|15-height, 16|31-model id
    uint flags = 0;

    flags |= modelId<<16;//Model id
    // For axis==2 (EAST/WEST, face>>1==2), quadSize.x=Y-span and .y=Z-span.
    // Our UV maps U→Z-direction (using .y span) and V→Y-direction (using .x span),
    // so swap the tile counts here to keep the fragment bounds-check consistent.
    ivec2 quadSizeForFlags = ((face>>1u)==2u) ? quadSize.yx : quadSize;
    flags |= (uint(quadSizeForFlags.x-1)<<8)|(uint(quadSizeForFlags.y-1)<<12);//quad size

    {//Cuttout
        flags |= faceHasAlphaCuttout(faceData);
        // bit1 = useAveragedMipDiscard (set for leaf blocks via hasAlphaCutoutOverride).
        // No merged-quad gate: even single-block leaf quads must use the averaged alpha
        // so that "Better Leaves" sparse side textures render solid at LOD distance.
        flags |= faceHasAlphaCuttoutOverride(faceData) << 1u;
    }

    //TODO: remove, there is no non mip code path anymore
    //flags |= uint(!modelHasMipmaps(model))<<1;//Not mipmaps

    flags |= faceTintState(faceData)<<2;
    flags |= face<<4;//Face

    return flags;
}

uint packVec4(vec4 vec) {
    uvec4 vec_=uvec4(vec*255)<<uvec4(24,16,8,0);
    return vec_.x|vec_.y|vec_.z|vec_.w;
}


#ifndef PATCHED_SHADER
float computeDirectionalFaceTint(bool isShaded, uint face);
#endif

uvec3 makeRemainingAttributes(const in BlockModel model, const in Quad quad, uint lodLevel, uint face) {
    uvec3 attributes = uvec3(0);

    uint lighting = extractLightId(quad);

    //Apply model colour tinting
    uint tintColour = model.colourTint;

    if (modelHasBiomeLUT(model)) {
        tintColour = colourData[tintColour + extractBiomeId(quad)];
    }

    #ifdef PATCHED_SHADER
    attributes.x = lighting;
    attributes.y = tintColour;
    #else
    bool isTranslucent = modelIsTranslucent(model);

    //afak, these are the same variable in vanilla, (i.e. shaded == ao)
    bool isShaded = modelIsShaded(model);
    bool hasAO = isShaded;

    vec4 tinting = getLighting(lighting);

    // Default to 0xFFFFFFFF (white multiply = no tint). If we leave it as 0 (black),
    // blocks whose biome LUT slot ran out (colourTint==uint(-1)) render completely black.
    uint conditionalTinting = 0xFFFFFFFFu;
    if (tintColour != uint(-1)) {
        conditionalTinting = tintColour;
    }

    uint addin = 0;
    if (!isTranslucent) {
        tinting.w = 0.0;
        //Encode the face, the lod level and
        uint encodedData = 0;
        encodedData |= face;
        encodedData |= (lodLevel<<3);
        encodedData |= uint(hasAO)<<6;
        encodedData |= (1u<<7); // bit 7: "this pixel has LOD geometry" — used by SSAO to skip cleared/vanilla pixels
        addin = encodedData;
    }

    tinting.rgb *= computeDirectionalFaceTint(isShaded, face);

    attributes.x = packVec4(tinting);
    attributes.y = conditionalTinting;
    attributes.z = addin|(face<<8);
    #endif

    return attributes;
}

void setupQuad(out QuadData quad, const in Quad rawQuad, uvec2 sPos, bool generateAttributes) {
    uint lodLevel = getLoDLevel(sPos);
    float lodScale = 1<<lodLevel;
    ivec3 baseSection = (getLoDPosition(sPos)<<lodLevel) - baseSectionPos;

    uint face = extractFace(rawQuad);
    uint modelId = extractStateId(rawQuad);
    BlockModel model = modelData[modelId];
    uint faceData = model.faceData[face];
    ivec2 quadSize = extractSize(rawQuad);

    if (generateAttributes) {
        quad.attributeData.x = makeQuadFlags(faceData, modelId, quadSize, model, face);
        quad.attributeData.yzw = makeRemainingAttributes(model, rawQuad, lodLevel, face);
    }

    vec4 faceSize = getFaceSize(faceData);
    #ifdef USE_SINGLE_TRI
    faceSize *= 2;
    #endif
    vec3 quadStart = extractPos(rawQuad);
    float depthOffset = extractFaceIndentation(faceData);
    quadStart += swizzelDataAxis(face>>1, vec3(faceSize.xz, mix(depthOffset, 1-depthOffset, float(face&1u))));

    quad.lodScale = lodScale;
    quad.axis = face>>1;
    quad.basePoint = (quadStart*lodScale)+vec3(baseSection<<5);
    #ifdef USE_SINGLE_TRI
    quad.quadSizeAddin = faceSize.yw * vec2(quadSize);
    #else
    quad.quadSizeAddin = faceSize.yw * vec2(quadSize);
    #endif
    quad.uvCorner = faceSize.xz;
}

vec4 getQuadCornerPos(in QuadData quad, uint cornerId) {
    vec2 cornerMask = vec2((cornerId>>1)&1u, cornerId&1u)*quad.lodScale;
    vec3 point = quad.basePoint + swizzelDataAxis(quad.axis,vec3(quad.quadSizeAddin*cornerMask,0));
    vec4 pos = MVP * vec4(point, 1.0f);
    pos.xy += taaOffset*pos.w;
    return pos;
}

#ifndef USE_NV_BARRY
vec2 getCornerUV(const in QuadData quad, uint cornerId) {
    if (quad.axis == 2u) {
        // axis==2 (EAST/WEST): swizzelDataAxis returns data.zxy, so cornerMask.x→world Y, cornerMask.y→world Z.
        // U must map to Z (horizontal) with the Z-span size (.y), V to Y (vertical) with the Y-span size (.x).
        return quad.uvCorner + vec2(quad.quadSizeAddin.y * (cornerId&1u), quad.quadSizeAddin.x * ((cornerId>>1)&1u));
    }
    return quad.uvCorner + quad.quadSizeAddin*vec2((cornerId>>1)&1u, cornerId&1u);
}
#endif

#ifndef PATCHED_SHADER
float computeDirectionalFaceTint(bool isShaded, uint face) {
    //Apply face tint
    if (isShaded) {
        //just index on a const array with the face as an index, will be much faster
        // or use a vector and select/sum
        // but per face might be easier?


        if ((face>>1) == 1) {//NORTH, SOUTH
            return Z_AXIS_FACE_TINT;
        } else if ((face>>1) == 2) {//EAST, WEST
            return X_AXIS_FACE_TINT;
        } else if (face == 1) {//UP
            return UP_FACE_TINT;
        }
        //DOWN
        return DOWN_FACE_TINT;
    } else {
        return NO_SHADE_FACE_TINT;
    }
}
#endif