package me.cortex.voxy.common.config.storage.other;

import it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.objects.Object2IntMap;
import it.unimi.dsi.fastutil.objects.Object2IntOpenHashMap;
import me.cortex.voxy.common.Logger;
import me.cortex.voxy.common.config.ConfigBuildCtx;
import me.cortex.voxy.common.config.storage.StorageBackend;
import me.cortex.voxy.common.config.storage.StorageConfig;
import me.cortex.voxy.common.util.MemoryBuffer;
import net.minecraft.world.level.levelgen.RandomSupport;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.function.LongConsumer;

//Segments the section data into multiple dbs
public class FragmentedStorageBackendAdaptor extends StorageBackend {
    private final StorageBackend[] backends;

    public FragmentedStorageBackendAdaptor(StorageBackend... backends) {
        this.backends = backends;
        int len = backends.length;
        if ((len&(len-1)) != 0) {
            throw new IllegalArgumentException("Backend count not a power of 2");
        }
    }

    private int getSegmentId(long key) {
        return (int) (RandomSupport.mixStafford13(RandomSupport.mixStafford13(key)^key)&(this.backends.length-1));
    }

    @Override
    public void iteratePositions(int level, LongConsumer consumer) {
        for (var backend : this.backends) {
            backend.iteratePositions(level, consumer);
        }
    }

    //TODO: reencode the key to be shifted one less OR
    // use like a mix64 to shuffle the key in getSegmentId so that
    // multiple layers of spliced storage backends can be stacked

    @Override
    public MemoryBuffer getSectionData(long key, MemoryBuffer scratch) {
        return this.backends[this.getSegmentId(key)].getSectionData(key, scratch);
    }

    @Override
    public void setSectionData(long key, MemoryBuffer data) {
        this.backends[this.getSegmentId(key)].setSectionData(key, data);
    }

    @Override
    public void deleteSectionData(long key) {
        this.backends[this.getSegmentId(key)].deleteSectionData(key);
    }

    @Override
    public void putIdMapping(int id, ByteBuffer data) {
        //Replicate the mappings over all the dbs to mean the chance of recovery in case of corruption is 30x
        for (var backend : this.backends) {
            backend.putIdMapping(id, data);
        }
    }

    private record EqualingArray(byte[] bytes) {
        @Override
        public boolean equals(Object obj) {
            return Arrays.equals(this.bytes, ((EqualingArray)obj).bytes);
        }

        @Override
        public int hashCode() {
            return Arrays.hashCode(this.bytes);
        }
    }

    @Override
    public Int2ObjectOpenHashMap<byte[]> getIdMappingsData() {
        Object2IntOpenHashMap<Int2ObjectOpenHashMap<EqualingArray>> verification = new Object2IntOpenHashMap<>();
        Int2ObjectOpenHashMap<EqualingArray> any = null;
        for (var backend : this.backends) {
            var mappings = backend.getIdMappingsData();
            if (mappings.isEmpty()) {
                //TODO: log a warning and attempt to replicate the data the other fragments
                continue;
            }
            var repackaged = new Int2ObjectOpenHashMap<EqualingArray>(mappings.size());
            for (var entry : mappings.int2ObjectEntrySet()) {
                repackaged.put(entry.getIntKey(), new EqualingArray(entry.getValue()));
            }
            verification.addTo(repackaged, 1);
            any = repackaged;
        }
        if (any == null) {
            return new Int2ObjectOpenHashMap<>();
        }

        if (verification.size() != 1) {
            Logger.error("Error id mapping not matching across all fragments, attempting to recover");
            Object2IntMap.Entry<Int2ObjectOpenHashMap<EqualingArray>> maxEntry = null;
            for (var entry : verification.object2IntEntrySet()) {
                if (maxEntry == null) { maxEntry = entry; }
                else {
                    if (maxEntry.getIntValue() < entry.getIntValue()) {
                        maxEntry = entry;
                    }
                }
            }

            var mapping = maxEntry.getKey();

            var out = new Int2ObjectOpenHashMap<byte[]>(mapping.size());
            for (var entry : mapping.int2ObjectEntrySet()) {
                out.put(entry.getIntKey(), entry.getValue().bytes);
            }
            return out;
        } else {
            var out = new Int2ObjectOpenHashMap<byte[]>(any.size());
            for (var entry : any.int2ObjectEntrySet()) {
                out.put(entry.getIntKey(), entry.getValue().bytes);
            }
            return out;
        }
    }

    @Override
    public void flush() {
        for (var db : this.backends) {
            db.flush();
        }
    }

    @Override
    public void close() {
        for (var db : this.backends) {
            db.close();
        }
    }

    @Override
    public List<StorageBackend> getChildBackends() {
        return List.of(this.backends);
    }

    public static class Config extends StorageConfig {
        public List<StorageConfig> backends = new ArrayList<>();

        @Override
        public List<StorageConfig> getChildStorageConfigs() {
            return new ArrayList<>(this.backends);
        }

        @Override
        public StorageBackend build(ConfigBuildCtx ctx) {
            StorageBackend[] builtBackends = new StorageBackend[this.backends.size()];
            for (int i = 0; i < this.backends.size(); i++) {
                //TODO: put each backend in a different folder?
                builtBackends[i] = this.backends.get(i).build(ctx);
            }
            return new FragmentedStorageBackendAdaptor(builtBackends);
        }

        public static String getConfigTypeName() {
            return "FragmentationAdaptor";
        }
    }

    public static class Config2 extends StorageConfig {
        public StorageConfig delegate;
        public String basePath;
        public int count;


        @Override
        public List<StorageConfig> getChildStorageConfigs() {
            return new ArrayList<>(Collections.singleton(this.delegate));
        }

        @Override
        public StorageBackend build(ConfigBuildCtx ctx) {
            StorageBackend[] builtBackends = new StorageBackend[this.count];
            for (int i = 0; i < this.count; i++) {
                ctx.pushPath(this.basePath+"_"+i);
                builtBackends[i] = this.delegate.build(ctx);
                ctx.popPath();
            }
            return new FragmentedStorageBackendAdaptor(builtBackends);
        }

        public static String getConfigTypeName() {
            return "AutoFragmentationAdaptor";
        }
    }
}
